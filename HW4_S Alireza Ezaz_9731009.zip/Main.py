import pandas
import numpy
import math
import matplotlib.pyplot as plt


def estimation(t):
    global b0, b1, b2
    return int(b0 + b1 * t + b2 * t * t)


numpy.set_printoptions(suppress=True)

covid_19 = pandas.read_csv("total_cases.csv", usecols=['World'])
data = list(covid_19.World)
last_7_days_data = data[-7:]
data = data[:-7]
print('\nData from total_cases.csv except last 7 days:({} days)\n\n'.format(len(data)), data, '\n')
print('Last 7 days data:\n', last_7_days_data, '\n\n')

Y = numpy.array(data).reshape(len(data), 1)
T = numpy.ones((len(data), 3))
for i, row in enumerate(T):
    row[1] = i
    row[2] = i * i

T_transpose = numpy.transpose(T)
T_transpose_T = numpy.matmul(T_transpose, T)
T_transpose_Y = numpy.matmul(T_transpose, Y)
answer = numpy.linalg.solve(T_transpose_T, T_transpose_Y)

# print(T_transpose_T)
# print(T_transpose_Y)
# print(Tinverse_T)
# print(answer)
b0 = answer[0][0]
b1 = answer[1][0]
b2 = answer[2][0]
estimations = []
for i in range(7):
    estimations.append(estimation(len(data) + i))

complete_estimation =[]
for i in range(len(data)):
    complete_estimation.append(estimation(i))
print('b0 , b1 , b2 are:\n', answer, '\n')
print('estimations for next 7 days are:\n',estimations)
plt.plot(data)
plt.ylabel('Covid_19')
plt.xlabel('days')
plt.show()

plt.plot(complete_estimation)
plt.ylabel('Covid_19 estimations')
plt.xlabel('days')
plt.show()




