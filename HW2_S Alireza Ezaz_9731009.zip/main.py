import numpy as np


def LU_Factorization(matrix, dim):
    lower = np.zeros((dim, dim))
    upper = np.zeros((dim, dim))

    for i in range(dim):

        # Upper Triangular
        for k in range(i, dim):

            # Summation of L(i, j) * U(j, k)
            sum = 0;
            for j in range(i):
                sum += (lower[i][j] * upper[j][k]);

                # Evaluating U(i, k)
            upper[i][k] = matrix[i][k] - sum;

            # Lower Triangular
        for k in range(i, dim):
            if (i == k):
                lower[i][i] = 1;  # Diagonal as 1
            else:

                # Summation of L(k, j) * U(j, i)
                sum = 0;
                for j in range(i):
                    sum += (lower[k][j] * upper[j][i]);

                    # Evaluating L(k, i)
                lower[k][i] = int((matrix[k][i] - sum) /
                                  upper[i][i]);

                # setw is for displaying nicely

    return lower, upper


def forward_substitution(matrix, dim):
    final = np.zeros((dim, dim + 1))
    for k in range(dim):
        answer = np.zeros((dim, dim + 1))
        answer[:dim, :dim] = matrix
        answer[:, dim] = np.identity(dim)[:, k]

        for i in range(dim):
            for j in range(i + 1, dim - 1):
                leading = matrix[i][j]
                print(leading)
                answer[j, :] = answer[j, :] - leading * answer[i,:]
        print('answ', answer)
        final[:, k] = answer[:, dim]
    return final


dim = int(input())
matrix = np.zeros((dim, dim))
for i in range(dim):
    matrix[i, :] = list(map(int, input().split()))
print('Matrix is:\n\n', matrix, '\n')

l, u = LU_Factorization(matrix, dim)
print('L is :\n\n', l, '\n')
print('U is :\n\n', u, '\n')
print(forward_substitution(l, dim))
