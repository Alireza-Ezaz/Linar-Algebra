import numpy as np


##################################################################################
def reduced_echleon_form(matrix, tol=1e-8, debug=False):
    A = matrix.copy()
    rows, cols = A.shape
    r = 0
    pivots_pos = []
    row_exchanges = np.arange(rows)
    for c in range(cols):
        ## Find the pivot row:
        pivot = np.argmax(np.abs(A[r:rows, c])) + r
        m = np.abs(A[pivot, c])

        if m <= tol:
            ## Skip column c, making sure the approximately zero terms are
            ## actually zero.
            A[r:rows, c] = np.zeros(rows - r)

        else:
            ## keep track of bound variables
            pivots_pos.append((r, c))

            if pivot != r:
                ## Swap current row and pivot row
                A[[pivot, r], c:cols] = A[[r, pivot], c:cols]
                row_exchanges[[pivot, r]] = row_exchanges[[r, pivot]]

            ## Normalize pivot row
            A[r, c:cols] = A[r, c:cols] / A[r, c];

            ## Eliminate the current column
            v = A[r, c:cols]
            ## Above (before row r):
            if r > 0:
                ridx_above = np.arange(r)
                A[ridx_above, c:cols] = A[ridx_above, c:cols] - np.outer(v, A[ridx_above, c]).T

            ## Below (after row r):
            if r < rows - 1:
                ridx_below = np.arange(r + 1, rows)
                A[ridx_below, c:cols] = A[ridx_below, c:cols] - np.outer(v, A[ridx_below, c]).T

            r += 1
        ## Check if done
        if r == rows:
            break
    return (A, pivots_pos)
    return matrix


############################################################################################
def find_basis_for_columnSpace(matrix, pivots):
    for p in pivots:
        pivot_row, pivot_col = p
        print(matrix[:, pivot_col].reshape(m, 1))
        print(",")


###########################################################################################
def find_basis_for_RowSpace(matrix, pivots):
    for p in pivots:
        pivot_row, pivot_col = p
        print(matrix[pivot_row, :].reshape(1, n))
        print(",")


###########################################################################################
def combinations(matrix, pivots):
    free_columns = [x for x in range(n)]

    new_matrix = np.zeros((m, len(pivots)))
    i = 0

    for p in pivots:
        pivot_row, pivot_col = p
        free_columns.remove(pivot_col)
        new_matrix[:, i] = (matrix[:, pivot_col])
        i += 1
    for i in free_columns:
        new_augmented_matrix = np.hstack((new_matrix, matrix[:, i].reshape(m, 1)))
        print('We are gonig to find column {} as combination of column basis\n'.format(i), new_augmented_matrix)
        print("Xi are:")
        print(reduced_echleon_form(new_augmented_matrix)[0])

        print('\n\n\n')


###########################################################################################
def find_basis_for_NullSpace(matrix, pivots):
    free_columns = [x for x in range(n)]
    pivot_columns = []

    for p in pivots:
        pivot_row, pivot_col = p
        free_columns.remove(pivot_col)
        pivot_columns.append(pivot_col)

    mat = np.zeros((n, n))
    for i in free_columns:
        mat[i, i] = 1
    k = 0
    for i in pivot_columns:
        for j in free_columns:
            mat[i][j] = - reduced_echleon_form(matrix)[0][k][j]
        k+=1
    for i in free_columns:
        print(mat[:,i].reshape(n , 1),'\n')


    ###########################################################################################


m, n = list(map(int, input().split()))
matrix = np.zeros((m, n))

for i in range(m):
    try:
        matrix[i] = list(map(int, input().split()))
    except(ValueError):
        raise NameError("Enter the matrix correctly")

augmented_matrix = np.hstack((matrix, np.zeros((m, 1))))
print("Augmented Matrix is :\n", augmented_matrix, '\n')

augmented_reduced_matrix, pivots = reduced_echleon_form(augmented_matrix)
print("Reduced Echolen Form is:\n", augmented_reduced_matrix, '\n')

print("Basis for column space:")
find_basis_for_columnSpace(matrix, pivots)

print("Basis for Row space:")
find_basis_for_RowSpace(matrix, pivots)

print("basis for Null Space")
find_basis_for_NullSpace(matrix, pivots)

print(("Other columns based on basis of column space:"))
combinations(matrix, pivots)
